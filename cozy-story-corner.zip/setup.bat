@echo off
REM The Cozy Story Corner - Quick Setup Script

echo.
echo ===================================
echo  The Cozy Story Corner Setup
echo ===================================
echo.

REM Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js is not installed!
    echo Please download it from https://nodejs.org/
    pause
    exit /b 1
)

echo Node.js is installed: 
node --version

echo.
echo [1/3] Installing dependencies...
call npm install

if errorlevel 1 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo [2/3] Creating .env file...
if not exist .env (
    copy .env.example .env
    echo .env file created!
    echo Please edit .env and change JWT_SECRET to a random string
) else (
    echo .env already exists
)

echo.
echo [3/3] Setup complete!
echo.
echo To start the server, run:
echo   node server.js
echo.
echo Then open http://localhost:5000 in your browser
echo.
pause
