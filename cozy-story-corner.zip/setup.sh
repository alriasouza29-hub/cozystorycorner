#!/bin/bash

# The Cozy Story Corner - Quick Setup Script

echo ""
echo "==================================="
echo "  The Cozy Story Corner Setup"
echo "==================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed!"
    echo "Please download it from https://nodejs.org/"
    exit 1
fi

echo "Node.js is installed: $(node --version)"

echo ""
echo "[1/3] Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

echo ""
echo "[2/3] Creating .env file..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo ".env file created!"
    echo "Please edit .env and change JWT_SECRET to a random string"
else
    echo ".env already exists"
fi

echo ""
echo "[3/3] Setup complete!"
echo ""
echo "To start the server, run:"
echo "  node server.js"
echo ""
echo "Then open http://localhost:5000 in your browser"
echo ""
